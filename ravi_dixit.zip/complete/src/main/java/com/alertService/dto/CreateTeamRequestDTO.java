package com.alertService.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

public class CreateTeamRequestDTO {

    private teamAttributes team;
    private DevelopersAttributes developers;

    @Getter
    @Setter
    @AllArgsConstructor
    public static class teamAttributes {
        private String name;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    public static class DevelopersAttributes {
        private String name;
        private String phoneNumber;
    }
}
