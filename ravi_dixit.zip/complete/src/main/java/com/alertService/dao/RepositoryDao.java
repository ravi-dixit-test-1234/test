package com.alertService.dao;

import com.alertService.model.Team;
import com.alertService.model.TeamMember;

public interface RepositoryDao {

    public boolean insertTEam(Team team);
    public TeamMember fetchTeamMember(String teamId, String memberName);

}
