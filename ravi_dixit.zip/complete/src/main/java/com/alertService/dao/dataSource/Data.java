package com.alertService.dao.dataSource;

import com.alertService.model.Team;

import java.util.HashMap;
import java.util.Map;

public class Data {
    private static Map<String, Team> teamMap = new HashMap<>();

    public boolean checkTeamExistence(String name) {
        return teamMap.containsKey(name);
    }

    public boolean insertTeam(String name, Team team) {
        teamMap.put(name, team);
    }


}
