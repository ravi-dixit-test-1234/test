package com.alertService.dao.impl;

import com.alertService.dao.RepositoryDao;
import com.alertService.model.Team;
import com.alertService.model.TeamMember;

public class RepositoryDaoImpl implements RepositoryDao {


    @Override
    public boolean insertTEam(Team team) {
        return false;
    }

    @Override
    public TeamMember fetchTeamMember(String teamId, String memberName) {
        return null;
    }
}
