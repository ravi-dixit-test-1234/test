package com.alertService.service;

import com.alertService.dto.CreateTeamRequestDTO;
import org.springframework.stereotype.Service;

@Service
public class CreateTeamService {

    public String createTeam(final CreateTeamRequestDTO createTeamRequestDTO) {




    }


}
