package com.alertService.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
abstract class TeamMember {
    private String name;
    private String id;
    private String teamId;
    private String phoneNumber;
}