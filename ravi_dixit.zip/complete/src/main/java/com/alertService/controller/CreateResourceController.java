package com.alertService.controller;

import com.alertService.dto.CreateTeamRequestDTO;
import com.alertService.service.CreateTeamService;
import com.alertService.validatoion.TeamDataValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateResourceController {

    @Autowired
    private CreateTeamService createTeamService;

    @Autowired
    private TeamDataValidator teamDataValidator;

    @PostMapping("/api/v1/create_team")
    public String createTeam(@RequestBody CreateTeamRequestDTO createTeamRequestDTO) {
       if (teamDataValidator.validateTeamDataRecord(createTeamRequestDTO)) {
           return createTeamService.createTeam(createTeamRequestDTO);
       }
       return "Invalid record";
    }

}