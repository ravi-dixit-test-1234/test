package com.alertService.validatoion;

import com.alertService.dto.CreateTeamRequestDTO;
import org.springframework.stereotype.Component;

@Component
public class TeamDataValidator {

    public boolean validateTeamDataRecord(final CreateTeamRequestDTO createTeamRequestDTO) {

//having logic
        return true;
    }

}
